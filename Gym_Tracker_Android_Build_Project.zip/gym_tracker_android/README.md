# Gym Tracker Android package

This project wraps the working Gym Tracker HTML app in a native Android WebView.

## Build the APK in GitHub Actions
1. Create a new GitHub repository.
2. Upload all files in this folder (keep the `.github/workflows/build-apk.yml` path).
3. Open the repository's **Actions** tab.
4. Run **Build Gym Tracker APK** (or push to `main`).
5. When the run succeeds, open the run and download the `Gym-Tracker-debug-APK` artifact.
6. Extract the ZIP; install `app-debug.apk` on your Android phone. You may need to allow installation from that source.

The APK is a debug build for personal testing, not a Play Store release.

## Notes
- App data is stored locally by the WebView on this device.
- The app requests no network permissions.
- Automatic step counting is not implemented by this HTML app; manual step entry remains available.
